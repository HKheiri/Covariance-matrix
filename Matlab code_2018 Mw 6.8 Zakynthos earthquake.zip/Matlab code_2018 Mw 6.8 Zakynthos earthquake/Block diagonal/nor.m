function pp = nor(A,sigma0,B,l)
Qy = make_Qy_new(sigma0,B);
invQy=eye(size(Qy))/Qy;
X=inv(A'*invQy*A)*A'*invQy*l;
r=A*X-l;
pp=norm(r);
end