function sp = make_Qy_new(sigma0,B)
ls=length(sigma0);
s=0;
for i=1:ls
    Qp(i).temp=sigma0(i)*B(i).temp;
    s=s+Qp(i).temp;
end
sp=sparse(s);
end