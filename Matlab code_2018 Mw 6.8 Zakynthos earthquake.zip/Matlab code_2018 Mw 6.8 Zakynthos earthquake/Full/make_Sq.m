function [S,q] = make_Sq(B,W,y,ls)
for i=1:ls
    f=B(i).temp;
    M1=W*f;
    for j=i:ls
        g=B(j).temp;
        M2=W*g;
        S(i,j)=trace(M1*M2);
    end
    M1=0;
    M2=0;
    f=0;
end

for i=2:ls
    for j=1:i-1
        S(i,j)=S(j,i);
    end
end

m1=y'*W; m2=W*y;
for i=1:ls
    f=B(i).temp;
    q(i,1)=m1*f*m2;
end
end