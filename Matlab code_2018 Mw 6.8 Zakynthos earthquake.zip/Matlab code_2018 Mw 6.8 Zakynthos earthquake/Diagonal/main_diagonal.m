clc
clear all
close all
%------------------- �Zakynthos for 151 samples --------------------------
%% inputs
tic
load Ash_151resample.dat
load L_151resample.dat
A=Ash_151resample;      %design matrix
y=L_151resample;        %observations
siz=151;                %size of samples
%%
I=eye(siz);O=zeros(siz);
c1=[I  O  O;
    O  O  O;
    O  O  O];
%
c2=[O  I   O;
    I  O   O;
    O  O   O];
% 
c3=[O  O  O;
    O  I  O;
    O  O  O];
% 
c4=[O  O  I;
    O  O  O;
    I  O  O];
% 
c5=[O  O  O;
    O  O  I;
    O  I  O];
% 
c6=[O  O   O;
    O  O   O;
    O  O   I];
%
c7=[O  I   I;
    I  O   I;
    I  I   O];
%
c8=[I   I   I;
    I   I   I;
    I   I   I];
%
% % %
O=zeros(3*siz);

Q(1).temp=[c1 O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O];
% % % %
Q(2).temp=[c3 O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O];
% % % % %
Q(3).temp=[c6 O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O;
    O  O O O O O O];
% % % % %
Q(4).temp=[O O  O O O O O;
    O c1 O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O];
% % % % %
Q(5).temp=[O O  O O O O O;
    O c3 O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O];
% % % % %
Q(6).temp=[O O  O O O O O;
    O c6 O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O;
    O O  O O O O O];
% % % % %
Q(7).temp=[O O O  O O O  O;
    O O O  O O O  O;
    O O c1 O O O  O;
    O O O  O O O  O;
    O O O  O O O  O;
    O O O  O O O  O;
    O O O  O O O  O];

% % % % %
Q(8).temp=[O O O  O O O  O;
    O O O  O O O  O;
    O O c3 O O O  O;
    O O O  O O O  O;
    O O O  O O O  O;
    O O O  O O O  O;
    O O O  O O O  O];
% % % % %
Q(9).temp=[O O O  O O O  O;
    O O O  O O O  O;
    O O c6 O O O  O;
    O O O  O O O  O;
    O O O  O O O  O;
    O O O  O O O  O;
    O O O  O O O  O];
% % % % %
Q(10).temp=[O O O O  O O O;
    O O O O  O O O;
    O O O O  O O O;
    O O O c1 O O O;
    O O O O  O O O;
    O O O O  O O O;
    O O O O  O O O];
% % % % %
Q(11).temp=[O O O O  O O O;
    O O O O  O O O;
    O O O O  O O O;
    O O O c3 O O O;
    O O O O  O O O;
    O O O O  O O O;
    O O O O  O O O];
% % % %
Q(12).temp=[O O O O  O O O;
    O O O O  O O O;
    O O O O  O O O;
    O O O c6 O O O;
    O O O O  O O O;
    O O O O  O O O;
    O O O O  O O O];
% % % %
Q(13).temp=[O O O O O  O O;
    O O O O O  O O;
    O O O O O  O O;
    O O O O O  O O;
    O O O O c1 O O;
    O O O O O  O O;
    O O O O O  O O];
% % % %
Q(14).temp=[O O O O O  O O;
    O O O O O  O O;
    O O O O O  O O;
    O O O O O  O O;
    O O O O c3 O O;
    O O O O O  O O;
    O O O O O  O O];
% % % %
Q(15).temp=[O O O O O  O O;
    O O O O O  O O;
    O O O O O  O O;
    O O O O O  O O;
    O O O O c6 O O;
    O O O O O  O O;
    O O O O O  O O];
% % % %
Q(16).temp=[O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O c1 O;
    O O O O O O  O];
% % % % % %
Q(17).temp=[O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O c3 O;
    O O O O O O  O];
% % % % % %
Q(18).temp=[O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O O  O;
    O O O O O c6 O;
    O O O O O O  O];
% % % % % % %
Q(19).temp=[O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O c1];

% % % % % % %
Q(20).temp=[O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O c3];
% % % % % % %
Q(21).temp=[O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O O;
    O O O O O O c6];
%%
sigma0=[ones(21,1)];
sigma00=sigma0;ls=length(sigma0);iteration=1;all_sigma=[sigma00];
ls=length(sigma0);
for i=1:ls
    B(i).temp=sparse(Q(i).temp);
end
Qy = make_Qy(sigma0,B);invQy=inv(Qy);
clear Q

toc1=toc
for i=1:20 % number of iteration
    disp(['iteration=' num2str(iteration)]);
    Qy = make_Qy(sigma0,B);
    invQy=eye(size(Qy))/Qy;
    W=invQy-invQy*A*inv(A'*invQy*A)*A'*invQy;                   
    W=sparse(W);
    S=zeros(ls);
    q=zeros(ls,1);
    [S,q] = make_Sq(B,W,y,ls);
    sigma=S\q;sigma0=sigma;
    Q_sigma=2*inv(S);
    format long g
    co_W(i)=log(condest(W));
    co_Qy(i)=(condest(Qy));
    filename=strcat('Qy',num2str(iteration));save(filename,'Qy');
    filename=strcat('Q_sigma',num2str(iteration));save(filename,'Q_sigma');
    pp(i) = nor(A,sigma,B,y);
    iteration=iteration+1;
    toc
end


